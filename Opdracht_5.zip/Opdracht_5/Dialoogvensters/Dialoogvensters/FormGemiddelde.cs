﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dialoogvensters
{
    public partial class FormGemiddelde : Form
    {
        public FormGemiddelde()
        {
            InitializeComponent();
        }

        BindingList<Single> getallenlijst = new BindingList<Single>();
        // BindingList ipv List ( https://stackoverflow.com/questions/17615069/how-to-refresh-datasource-of-a-listbox )
        private void button1_Click(object sender, EventArgs e)
        {
            DialogNieuwGetal dlg1 = new DialogNieuwGetal();
            dlg1.ShowDialog();
            Single g = dlg1.Getal;
 
            getallenlijst.Add(g);

            this.listBox1.DataSource = getallenlijst;
         
            int n = getallenlijst.Count();
            float som = getallenlijst.Sum(); 
            Single gem = som / n;

            this.textBox1.Text = gem.ToString();
        }
    }
}
