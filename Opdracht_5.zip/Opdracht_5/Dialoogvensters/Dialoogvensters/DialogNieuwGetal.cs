﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dialoogvensters
{
    public partial class DialogNieuwGetal : Form
    {
        public DialogNieuwGetal()
        {
            InitializeComponent();
        }


        private Single _getal;
        public Single Getal
        {
            get { return _getal; }
            set { _getal = value; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            if (!String.IsNullOrEmpty(textBox1.Text))
            {
                _getal = float.Parse(textBox1.Text);
                this.Close();
            } else
            {
                string message = "Vul een waarde in";
                MessageBox.Show(message, "Fout");
            }
        }

    }
}
