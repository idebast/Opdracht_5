﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dialoogvensters
{
    public partial class FormParent : Form
    {
        public FormParent()
        {
            InitializeComponent();

            FormGemiddelde f1 = new FormGemiddelde();
            f1.MdiParent = this;
            f1.Show();
        }

    }
}
