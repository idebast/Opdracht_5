﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Spelen_met_Kleuren
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int locationX, locationY;
    

        List<Rectangle> _rectangles = new List<Rectangle>();
        private void button1_Click_1(object sender, EventArgs e)
        {
            locationX = locationX + 20;
            locationY = locationY + 20;
            var rectangle = new Rectangle(locationX, locationY, 50, 30);
            this._rectangles.Add(rectangle);
            this.Invalidate(); 
        }

        

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var rectangle in this._rectangles)
            {
                e.Graphics.DrawRectangle(Pens.Black, rectangle);
            }
        }
     
    } 
}
